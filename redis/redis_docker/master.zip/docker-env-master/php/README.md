###  php 目录说明

- Dockerfile 文件， php镜像的构造文件

- php-fpm.conf 文件， php配置文件

- php.ini 文件，  php配置文件，主要用于扩展库的控制，以及一些功能的管理。
