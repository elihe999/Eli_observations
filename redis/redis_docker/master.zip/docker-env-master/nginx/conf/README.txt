# 这里是docker容器 Nginx服务的配置文件，
# 如需新增服务和配置，请到nginx/conf/conf.d文件夹中新建配置文件，
# 建议：一个服务单独使用一个配置文件
# 提示：如需使用nginx环境变量，请到 nginx/conf/conf.d/params 文件夹下新建 环境变量的配置文件 

