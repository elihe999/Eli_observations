<?php
        echo phpinfo();

